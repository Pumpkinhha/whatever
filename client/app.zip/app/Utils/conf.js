
var map = {'uniE600':'58880','uniE601':'58881','uniE602':'58882','uniE603':'58883','uniE604':'58884','uniE606':'58886','uniE607':'58887','uniE608':'58888','uniE609':'58889','uniE60A':'58890','uniE60B':'58891','uniE60C':'58892','uniE60D':'58893','uniE60E':'58894','uniE60F':'58895','uniE610':'58896','uniE611':'58897','uniE612':'58898','uniE613':'58899','uniE614':'58900','uniE615':'58901','uniE616':'58902','uniE617':'58903','uniE618':'58904','uniE619':'58905','uniE61A':'58906','uniE61B':'58907','x':'120',}
;module.exports = name => String.fromCharCode(map[name])
;module.exports.map = map
